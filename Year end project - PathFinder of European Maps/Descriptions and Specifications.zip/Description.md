### Projet TrackFinder

TrackFinder s'adresse aux randonneurs souhaitant se balader ou bien aux globetrotters voulant
s'éloigner des sentiers battus sans tomber dans un ravin.
Il se base sur les données topologiques de l'Europe pour trouver un itinéraire en fonction des
préférences de l'utilisateur pour atteindre à sa destination sans véhicules motorisés.
